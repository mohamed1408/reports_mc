import { Component, OnInit } from '@angular/core'
import { AuthService } from 'src/app/auth.service'
import { saveAs } from 'file-saver'
import { timer } from 'rxjs'
import { finalize, switchMap } from 'rxjs/operators'
declare const XLSX: any
@Component({
  selector: 'app-biz1book-main',
  templateUrl: './biz1book-main.component.html',
  styleUrls: ['./biz1book-main.component.scss'],
})
export class Biz1bookMainComponent implements OnInit {
  date = null
  gstNo = '33APUPK5773P1ZW'
  cata = 'Others'
  storereport: any
  selectedValue = null
  selectedValue2 = null
  selectedValue3 = null
  loading = false

  constructor(private Auth: AuthService) {}

  ngOnInit(): void {
    const currentDate = new Date()
    this.date = this.getFirstDateOfMonth(currentDate.toISOString().slice(0, 10))
  }

  onChange(result: string): void {
    this.date = this.getFirstDateOfMonth(result)
  }
  locgst: any
  locdate: any
  exportdate: any
  getrept() {
    // timer(10000)
    const nextMonth = this.getNextMonth(this.date)
    this.exportdate = nextMonth
    this.loading = true
    timer(10000)
      .pipe(
        switchMap(() => {
          return this.Auth.GetRptBiz1Pos(
            nextMonth,
            this.selectedValue,
            this.selectedValue2,
            this.selectedValue3,
          )
        }),
        finalize(() => (this.loading = false)),
      )
      .subscribe(data => {
        console.log(data)
        this.storereport = data['table']
        console.log(this.storereport)
        this.storereport.forEach(row => {
          const dateParts = row.rptdate.split('T')[0].split('-')
          row.rptdate = `${dateParts[2]}-${dateParts[1]}-${dateParts[0]}`
        })
      })

    // if (localStorage.getItem('gst') === null && localStorage.getItem('seledate') === null) {
    //   timer(10000)
    //     .pipe(
    //       switchMap(() => {
    //         return this.Auth.GetRptBiz1Pos(
    //           nextMonth,
    //           this.selectedValue,
    //           this.selectedValue2,
    //           this.selectedValue3,
    //         )
    //       }),
    //       finalize(() => (this.loading = false)),
    //     )
    //     .subscribe(
    //       data => {
    //         console.log(data)
    //         this.storereport = data['table']
    //         console.log(this.storereport)

    //         this.storereport.forEach(row => {
    //           const dateParts = row.rptdate.split('T')[0].split('-')
    //           row.rptdate = `${dateParts[2]}-${dateParts[1]}-${dateParts[0]}`
    //         })
    //       },
    //       error => {
    //         console.error('Error fetching data:', error)
    //       },
    //     )
    //   localStorage.setItem('gst', this.selectedValue)
    //   localStorage.setItem('seledate', nextMonth)
    // } else {
    //   this.locgst = localStorage.getItem('gst')
    //   console.log(this.locgst)
    //   this.locdate = localStorage.getItem('seledate')
    //   console.log(this.locdate)
    //   if (nextMonth == this.locdate && this.selectedValue == this.locgst) {
    //     timer(10000)
    //       .pipe(
    //         switchMap(() => {
    //           return this.Auth.GetRptBiz1Pos(
    //             nextMonth,
    //             this.selectedValue,
    //             this.selectedValue2,
    //             this.selectedValue3,
    //           )
    //         }),
    //         finalize(() => (this.loading = false)),
    //       )
    //       .subscribe(
    //         data => {
    //           console.log(data)
    //           this.storereport = data['table']
    //           console.log(this.storereport)

    //           this.storereport.forEach(row => {
    //             const dateParts = row.rptdate.split('T')[0].split('-')
    //             row.rptdate = `${dateParts[2]}-${dateParts[1]}-${dateParts[0]}`
    //           })
    //         },
    //         error => {
    //           console.error('Error fetching data:', error)
    //         },
    //       )
    //   } else {
    //     console.log('hii')
    //     timer(50)
    //   }
    // }

    // this.loading = true
  }

  fetchReportData() {
    const nextMonth = this.getNextMonth(this.date)
    this.Auth.GetRptBiz1Pos(
      nextMonth,
      this.selectedValue,
      this.selectedValue2,
      this.selectedValue3,
    ).subscribe(
      data => {
        console.log(data)
        this.storereport = data['table']
        console.log(this.storereport)

        this.storereport.forEach(row => {
          const dateParts = row.rptdate.split('T')[0].split('-')
          row.rptdate = `${dateParts[2]}-${dateParts[1]}-${dateParts[0]}`
        })

        this.loading = false
      },
      error => {
        this.loading = false
        console.error('Error fetching data:', error)
      },
    )
  }

  exportToCSV() {
    let aoa = [
      [this.selectedValue],
      [
        'Product',
        'Amt',
        'Tax %',
        'SGST',
        'CGST',
        'SGST Amt',
        'CGST Amt',
        'Tax Amount',
        'Total Amount',
      ],
    ]
    this.storereport.forEach(js => {
      aoa.push(Object.values(js).slice(1))
    })
    let worksheet = XLSX.utils.aoa_to_sheet(aoa)
    Object.keys(worksheet).forEach(i => {
      // console.log(i,worksheet[i]);
      if (typeof worksheet[i] != 'object') return
      let cell = XLSX.utils.decode_cell(i)

      worksheet[i].s = {
        // styling for all cells
        font: {
          name: 'arial',
          sz: 10,
        },
      }

      if (cell.r == 0) {
        worksheet[i].s.fill = { fgColor: { rgb: 'd8e5f8' } }
        worksheet[i].s.font.bold = true
      }

      if (cell.r == 1) {
        worksheet[i].s.font.bold = true
        worksheet[i].s.border = {
          top: { style: 'thin', color: { rgb: '000000' } },
          right: { style: 'thin', color: { rgb: '000000' } },
          bottom: { style: 'thin', color: { rgb: '000000' } },
          left: { style: 'thin', color: { rgb: '000000' } },
        }
      }
    })
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, worksheet, 'data')
    XLSX.writeFile(wb, this.selectedValue + this.exportdate + '.xlsx')
    return

    let csvData = 'Product,Amount,Tax%,SGST,CGST,SGST Amt,CGST Amt,Tax Amount,Total Amount\r\n'
    this.storereport.forEach(row => {
      csvData += `${row.product}, ${row.amount}, ${row.taxpercent}, ${row.cgst},  ${row.sgst}, ${row.cgstAmt}, ${row.sgstAmt}, ${row.taxAmount}, ${row.totalAmount}\r\n`
    })
    const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8' })
    const fileName = 'Exported - ' + this.locgst
    saveAs(blob, fileName + new Date().getTime())
  }

  onSelectedValueChange(): void {
    console.log(this.selectedValue2)
  }

  onSelectedValueChange2(): void {
    console.log(this.selectedValue3)
  }

  private getFirstDateOfMonth(dateString: string): string {
    const date = new Date(dateString)
    date.setDate(1)
    return date.toISOString().slice(0, 10)
  }

  private getNextMonth(dateString: string): string {
    const date = new Date(dateString)
    date.setMonth(date.getMonth())
    date.setDate(1)
    return date.toISOString().slice(0, 10)
  }

  isSubmitEnabled(): boolean {
    return this.date !== null && this.selectedValue !== null && this.selectedValue2 !== null
  }

  isExportEnabled(): boolean {
    return this.storereport && this.storereport.length > 0
  }
}
